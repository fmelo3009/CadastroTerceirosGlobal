-- Execute no Supabase SQL Editor antes de testar o novo formulário.
-- Adequação dos campos do banco ao formulário revisado pela advocacia.
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS submission_id uuid;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS estado text;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS faixa_etaria text;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS area_interesse text;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS escolaridade text;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS experiencias text;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS cursos text;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS perfil_profissional text;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS curriculo_path text;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS consentimento boolean NOT NULL DEFAULT false;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS consentimento_versao text;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS consentimento_em timestamptz;
ALTER TABLE public.terceirizados ADD COLUMN IF NOT EXISTS criado_em timestamptz NOT NULL DEFAULT now();

-- Campos antigos que a advocacia orientou NÃO coletar deixam de ser obrigatórios.
ALTER TABLE public.terceirizados ALTER COLUMN cpf_cnpj DROP NOT NULL;
ALTER TABLE public.terceirizados ALTER COLUMN cep DROP NOT NULL;
ALTER TABLE public.terceirizados ALTER COLUMN endereco DROP NOT NULL;
ALTER TABLE public.terceirizados ALTER COLUMN complemento DROP NOT NULL;

-- RLS: envio público somente de PF com consentimento explícito.
ALTER TABLE public.terceirizados ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "publico_pode_cadastrar" ON public.terceirizados;
DROP POLICY IF EXISTS "publico_pode_cadastrar_pf" ON public.terceirizados;
CREATE POLICY "publico_pode_cadastrar_pf" ON public.terceirizados FOR INSERT TO anon WITH CHECK (tipo='PF' AND consentimento=true);

-- Storage: permite somente upload público no bucket documentos.
DROP POLICY IF EXISTS "publico_pode_enviar_documentos" ON storage.objects;
CREATE POLICY "publico_pode_enviar_documentos" ON storage.objects FOR INSERT TO anon WITH CHECK (bucket_id='documentos');

-- IMPORTANTE: a exclusão automática após 12 meses deve ser configurada no backend/cron.
-- Não é seguro executar a exclusão pelo GitHub Pages.
